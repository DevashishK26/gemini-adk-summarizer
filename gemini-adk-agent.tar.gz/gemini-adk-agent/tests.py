"""
Tests for the Text Summarization Agent.

Run locally:
    pip install pytest pytest-asyncio httpx
    GOOGLE_API_KEY=<key> pytest tests.py -v

Set SKIP_INTEGRATION=1 to skip live API calls.
"""

from __future__ import annotations

import json
import os

import pytest
from fastapi.testclient import TestClient

# ── Unit tests (no API key needed) ───────────────────────────────────────────

def test_summarize_text_tool_word_count():
    from agent import summarize_text

    result = summarize_text("Hello world this is a test")
    assert result["word_count"] == 6


def test_summarize_text_tool_returns_dict():
    from agent import summarize_text

    result = summarize_text("Some text")
    assert isinstance(result, dict)
    assert "summary" in result
    assert "key_points" in result
    assert "word_count" in result


def test_create_agent_returns_agent():
    from agent import create_summarization_agent
    from google.adk.agents import Agent

    agent = create_summarization_agent()
    assert isinstance(agent, Agent)
    assert agent.name == "text_summarization_agent"


# ── Integration tests (require GOOGLE_API_KEY) ────────────────────────────────

SKIP_INTEGRATION = os.getenv("SKIP_INTEGRATION", "0") == "1"
SKIP_MSG = "Set SKIP_INTEGRATION=0 and provide GOOGLE_API_KEY to run."


@pytest.mark.skipif(SKIP_INTEGRATION, reason=SKIP_MSG)
def test_health_endpoint():
    from main import app

    with TestClient(app) as client:
        resp = client.get("/")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"


@pytest.mark.skipif(SKIP_INTEGRATION, reason=SKIP_MSG)
def test_summarize_endpoint_valid():
    from main import app

    sample_text = (
        "Artificial intelligence (AI) is intelligence demonstrated by machines, "
        "as opposed to the natural intelligence displayed by animals including humans. "
        "AI research has been defined as the field of study of intelligent agents, "
        "which refers to any system that perceives its environment and takes actions "
        "that maximize its chance of achieving its goals. The term 'artificial intelligence' "
        "had previously been used to describe machines that mimic and display 'human' "
        "cognitive skills associated with the human mind, such as learning and problem-solving."
    )

    with TestClient(app) as client:
        resp = client.post("/summarize", json={"text": sample_text})
        assert resp.status_code == 200
        data = resp.json()
        assert "summary" in data
        assert "key_points" in data
        assert isinstance(data["key_points"], list)
        assert "word_count" in data
        assert data["word_count"] > 0
        assert "session_id" in data
        assert "elapsed_ms" in data


@pytest.mark.skipif(SKIP_INTEGRATION, reason=SKIP_MSG)
def test_summarize_endpoint_short_text_rejected():
    from main import app

    with TestClient(app) as client:
        resp = client.post("/summarize", json={"text": "Hi"})
        assert resp.status_code == 422  # Pydantic min_length validation


@pytest.mark.skipif(SKIP_INTEGRATION, reason=SKIP_MSG)
def test_chat_endpoint():
    from main import app

    with TestClient(app) as client:
        resp = client.post("/chat", json={"message": "What can you do?"})
        assert resp.status_code == 200
        data = resp.json()
        assert "response" in data
        assert len(data["response"]) > 0
